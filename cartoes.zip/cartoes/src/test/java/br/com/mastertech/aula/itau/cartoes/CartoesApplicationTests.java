package br.com.mastertech.aula.itau.cartoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
